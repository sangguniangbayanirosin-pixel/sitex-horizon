import { inSorsogon } from "./geo";

export interface PhoneFix {
  lat: number;
  lng: number;
  speedKmh: number;
  accuracyM: number;
  heading: number | null;
  inProvince: boolean;
}

export function startPhoneWatch(
  onFix: (fix: PhoneFix) => void,
  onError: (message: string) => void,
): () => void {
  if (typeof navigator === "undefined" || !navigator.geolocation) {
    onError("This phone has no Geolocation API.");
    return () => undefined;
  }

  const id = navigator.geolocation.watchPosition(
    (pos) => {
      const speedMs = pos.coords.speed;
      onFix({
        lat: pos.coords.latitude,
        lng: pos.coords.longitude,
        speedKmh: speedMs != null && speedMs >= 0 ? speedMs * 3.6 : 0,
        accuracyM: pos.coords.accuracy,
        heading: pos.coords.heading != null && !Number.isNaN(pos.coords.heading) ? pos.coords.heading : null,
        inProvince: inSorsogon({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      });
    },
    (err) => {
      if (err.code === 1) onError("Location permission denied.");
      else if (err.code === 2) onError("GPS unavailable.");
      else onError("GPS timed out. Try again outdoors.");
    },
    { enableHighAccuracy: true, maximumAge: 1000, timeout: 10000 },
  );

  return () => navigator.geolocation.clearWatch(id);
}
