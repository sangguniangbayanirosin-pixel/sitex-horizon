import { createFileRoute } from "@tanstack/react-router";
import { AdBillboard } from "@/components/fleet/ad-billboard";
import { AnnouncementBanner } from "@/components/fleet/announcement-banner";
import { ConfirmedSigns } from "@/components/fleet/coming-sign";
import { ArrivalBoard } from "@/components/fleet/arrival-board";
import { HotlineStrip } from "@/components/fleet/hotline-strip";
import { JourneyPlanner } from "@/components/fleet/journey-planner";
import { LiveMap } from "@/components/fleet/live-map";
import { MunicipalityBoard } from "@/components/fleet/municipality-board";
import { NextArrivals } from "@/components/fleet/next-arrivals";
import { SitexLiveReel } from "@/components/fleet/sitex-stage";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { useFleet } from "@/lib/fleet/store";

export const Route = createFileRoute("/")({ component: Terminal });

function Terminal() {
  const buses = useFleet((s) => s.buses);
  const now = useFleet((s) => s.now);
  const weather = useFleet((s) => s.weather);
  const active = buses.filter((b) => b.status === "en-route" || b.status === "delayed").length;
  const last = Math.max(...buses.map((b) => b.lastFixAt));
  const age = Math.max(0, Math.round((now - last) / 1000));

  return (
    <div className="flex flex-col gap-5">
      <section className="relative overflow-hidden rounded-xl outline outline-1 -outline-offset-1 outline-fg/15">
        <SitexLiveReel className="relative aspect-video min-h-56 w-full md:min-h-96" />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-black/70 via-black/25 to-transparent" />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />
        <div className="absolute inset-0 flex flex-col justify-end p-5 md:p-7">
          <div className="mb-3">
            <Badge tone="live">HD live</Badge>
          </div>
          <p className="text-xs font-medium uppercase tracking-widest text-sky-300">
            SM Sorsogon · Balogo
          </p>
          <h1 className="font-display text-3xl font-semibold tracking-tight text-white md:text-5xl">
            SITEX live board
          </h1>
          <p className="mt-1 max-w-xl text-sm text-sky-100/80">
            Sorsogon Integrated Terminal Exchange. Arrivals update from each bus
            phone GPS speed — not a printed timetable.
          </p>
        </div>
      </section>

      <AnnouncementBanner />

      <ConfirmedSigns huge />

      <Card>
        <p className="mb-3 text-xs font-medium uppercase tracking-wide text-accent">
          Next buses to SITEX
        </p>
        <NextArrivals buses={buses} />
      </Card>

      <JourneyPlanner />

      <AdBillboard />

      <div className="flex flex-wrap items-end justify-between gap-3">
        <p className="font-mono text-xs text-muted">
          {active} buses live · GPS {age}s ago · weather {weather}
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.35fr_1fr]">
        <Card className="p-3 md:p-4">
          <p className="mb-2 text-xs font-medium uppercase tracking-wide text-accent">Live GPS map</p>
          <LiveMap buses={buses} />
        </Card>
        <Card>
          <p className="mb-3 text-xs font-medium uppercase tracking-wide text-accent">All arrivals</p>
          <ArrivalBoard buses={buses} />
        </Card>
      </div>

      <Card>
        <MunicipalityBoard />
      </Card>

      <Card>
        <p className="text-xs font-medium uppercase tracking-wide text-muted">How live ETA works</p>
        <p className="mt-2 max-w-3xl text-sm text-fg/90">
          The driver or conductor shares this phone’s built-in GPS — not a GPS number.
          Each fix includes latitude, longitude, and speed. Remaining road distance is
          divided by that speed every second:{" "}
          <span className="font-mono text-accent">ETA = distance ÷ velocity</span>. Wait time
          plus official road km to your town is your time home.
        </p>
      </Card>

      <HotlineStrip />
    </div>
  );
}
