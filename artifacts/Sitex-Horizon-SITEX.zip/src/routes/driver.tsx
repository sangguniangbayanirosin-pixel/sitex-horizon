import { createFileRoute } from "@tanstack/react-router";
import { DriverConfirmPanel } from "@/components/fleet/coming-sign";
import { PhoneGps } from "@/components/fleet/phone-gps";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { etaMinutes, formatEta, formatKm, formatSpeed } from "@/lib/fleet/eta";
import { useFleet } from "@/lib/fleet/store";

export const Route = createFileRoute("/driver")({ component: Driver });

function Driver() {
  const buses = useFleet((s) => s.buses);
  const selectedId = useFleet((s) => s.selectedBusId);
  const selectBus = useFleet((s) => s.selectBus);
  const setDriverSpeed = useFleet((s) => s.setDriverSpeed);
  const startTrip = useFleet((s) => s.startTrip);
  const endTrip = useFleet((s) => s.endTrip);
  const bus = buses.find((b) => b.id === selectedId) ?? buses[0];

  if (!bus) return null;

  return (
    <div className="mx-auto flex max-w-lg flex-col gap-4">
      <div>
        <h1 className="font-display text-3xl font-semibold tracking-tight">Driver / conductor</h1>
        <p className="mt-1 text-sm text-muted">
          Share this phone’s GPS. Speed changes update the public ETA on every
          Sitex screen that is online — terminal TVs, passenger phones, admin.
        </p>
      </div>

      <Card>
        <label className="text-xs font-medium uppercase tracking-wide text-muted" htmlFor="bus-select">
          Your bus
        </label>
        <select
          id="bus-select"
          className="mt-1 h-11 w-full rounded-md border border-border bg-bg px-3 text-sm"
          value={bus.id}
          onChange={(e) => selectBus(e.target.value)}
        >
          {buses.map((b) => (
            <option key={b.id} value={b.id}>
              {b.plate} · {b.destination}
            </option>
          ))}
        </select>
        <div className="mt-4 flex items-start justify-between gap-3">
          <div>
            <p className="font-mono text-lg">{bus.plate}</p>
            <p className="text-sm text-muted">
              {bus.destination} · {bus.zip} · {bus.via} · {bus.operator}
            </p>
          </div>
          <Badge
            tone={
              bus.status === "delayed"
                ? "warn"
                : bus.status === "en-route"
                  ? "ok"
                  : bus.status === "suspended"
                    ? "danger"
                    : "muted"
            }
          >
            {bus.status}
          </Badge>
        </div>
        <dl className="mt-4 grid grid-cols-3 gap-3 font-mono text-sm">
          <div>
            <dt className="text-xs text-muted">Left</dt>
            <dd>{formatKm(bus.remainingKm)}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted">Speed</dt>
            <dd>{formatSpeed(bus.speedKmh)}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted">ETA</dt>
            <dd>{formatEta(etaMinutes(bus.remainingKm, bus.speedKmh))}</dd>
          </div>
        </dl>
        <div className="mt-4">
          <label htmlFor="speed" className="text-xs font-medium uppercase tracking-wide text-muted">
            Speed override (demo)
          </label>
          <input
            id="speed"
            type="range"
            min={0}
            max={100}
            value={Math.round(bus.speedKmh)}
            onChange={(e) => setDriverSpeed(bus.id, Number(e.target.value))}
            className="mt-2 w-full"
          />
        </div>
        <div className="mt-4 flex gap-2">
          <Button className="flex-1" onClick={() => startTrip(bus.id)}>
            Start trip
          </Button>
          <Button className="flex-1" variant="secondary" onClick={() => endTrip(bus.id)}>
            End trip
          </Button>
        </div>
      </Card>

      <DriverConfirmPanel busId={bus.id} />

      <PhoneGps busId={bus.id} />
    </div>
  );
}
