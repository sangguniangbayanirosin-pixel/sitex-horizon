import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { startPhoneWatch } from "@/lib/fleet/gps";
import { useFleet } from "@/lib/fleet/store";

export function PhoneGps({ busId }: { busId: string }) {
  const apply = useFleet((s) => s.applyPhoneFix);
  const stop = useFleet((s) => s.stopPhoneGps);
  const bus = useFleet((s) => s.buses.find((b) => b.id === busId));
  const [on, setOn] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (!on) return;
    const clear = startPhoneWatch(
      (fix) => apply(busId, fix),
      (message) => {
        setErr(message);
        setOn(false);
      },
    );
    return () => {
      clear();
      stop(busId);
    };
  }, [on, busId, apply, stop]);

  return (
    <div className="rounded-lg border border-border bg-bg/50 p-4">
      <p className="text-xs font-medium uppercase tracking-wide text-muted">Phone GPS</p>
      <p className="mt-1 text-sm text-muted">
        Uses this phone’s built-in GPS — latitude, longitude, and speed. Not a GPS number.
      </p>
      <Button
        className="mt-3 w-full"
        variant={on ? "secondary" : "default"}
        onClick={() => {
          setErr(null);
          setOn((v) => !v);
        }}
      >
        {on ? "Stop sharing location" : "Share live GPS"}
      </Button>
      {on && bus && (
        <p className="mt-2 font-mono text-xs text-accent">
          {bus.lat.toFixed(5)}, {bus.lng.toFixed(5)} · {Math.round(bus.speedKmh)} km/h
          {bus.gpsAccuracyM != null ? ` · ±${Math.round(bus.gpsAccuracyM)} m` : ""}
        </p>
      )}
      {err && <p className="mt-2 text-sm text-danger">{err}</p>}
    </div>
  );
}
