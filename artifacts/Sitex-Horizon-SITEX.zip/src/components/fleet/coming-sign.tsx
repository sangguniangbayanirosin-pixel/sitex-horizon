import { MiniBus } from "@/components/fleet/mini-bus";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { colorForRoute } from "@/lib/fleet/colors";
import { useFleet } from "@/lib/fleet/store";
import type { Bus, ComingAsk } from "@/lib/fleet/types";
import { cn } from "@/lib/utils";

function liveAsks(asks: ComingAsk[], now: number) {
  const cutoff = now - 45 * 60_000;
  return asks.filter((a) => {
    if (a.status === "expired") return false;
    if (a.status === "confirmed") return (a.confirmedAt ?? a.askedAt) > cutoff;
    return a.askedAt > now - 2 * 60 * 60_000;
  });
}

export function ConfirmedSigns({ huge = false }: { huge?: boolean }) {
  const asks = useFleet((s) => s.asks);
  const now = useFleet((s) => s.now) || Date.now();
  const confirmed = liveAsks(asks, now).filter((a) => a.status === "confirmed");
  if (confirmed.length === 0) return null;

  return (
    <div className="flex flex-col gap-3">
      {confirmed.map((a) => (
        <section
          key={a.id}
          className={cn(
            "confirm-sign rounded-xl px-5 py-5 md:px-7 md:py-6",
            huge && "md:py-8",
          )}
        >
          <p className="text-xs font-medium uppercase tracking-[0.22em] text-emerald-100">
            Conductor confirmed
          </p>
          <p
            className={cn(
              "mt-1 font-display font-semibold tracking-tight text-white",
              huge ? "text-4xl md:text-6xl" : "text-3xl md:text-4xl",
            )}
          >
            BUS {a.plate}
          </p>
          <p className={cn("mt-1 font-bold uppercase tracking-wide text-amber-200", huge ? "text-2xl md:text-4xl" : "text-xl")}>
            {a.destination} is coming to SITEX
          </p>
          <p className="mt-2 text-sm text-sky-100/85">
            Driver / conductor tapped Confirmed. Plate {a.plate} · zip {a.zip}.
          </p>
        </section>
      ))}
    </div>
  );
}

export function PassengerAskPanel({ buses }: { buses: Bus[] }) {
  const asks = useFleet((s) => s.asks);
  const now = useFleet((s) => s.now) || Date.now();
  const askIfComing = useFleet((s) => s.askIfComing);
  const live = liveAsks(asks, now);
  const rows = buses.filter((b) => b.status === "en-route" || b.status === "delayed" || b.status === "idle");

  return (
    <Card>
      <p className="text-xs font-medium uppercase tracking-wide text-accent">Ask the conductor</p>
      <h2 className="font-display text-2xl font-semibold tracking-tight">Is this bus coming?</h2>
      <p className="mt-1 text-sm text-muted">
        Send a ping to the driver or conductor. When they tap Confirmed, the plate lights up on every SITEX screen.
      </p>
      <ul className="mt-4 flex flex-col gap-2">
        {rows.map((b) => {
          const mine = live.find((a) => a.busId === b.id);
          return (
            <li
              key={b.id}
              className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border px-3 py-3"
              style={{ borderLeft: `4px solid ${colorForRoute(b.routeId)}` }}
            >
              <div className="flex min-w-0 items-center gap-2">
                <MiniBus routeId={b.routeId} size={28} />
                <div>
                  <p className="font-mono text-sm font-bold">{b.plate}</p>
                  <p className="text-xs uppercase tracking-wide text-muted">{b.destination}</p>
                </div>
              </div>
              {mine?.status === "confirmed" ? (
                <span className="rounded-full bg-ok/15 px-3 py-1 text-xs font-bold uppercase tracking-wide text-ok">
                  Confirmed
                </span>
              ) : mine?.status === "pending" ? (
                <span className="ask-pulse rounded-full bg-warn/15 px-3 py-1 text-xs font-bold uppercase tracking-wide text-warn">
                  Waiting…
                </span>
              ) : (
                <Button size="sm" onClick={() => askIfComing(b.id)}>
                  Ask if coming
                </Button>
              )}
            </li>
          );
        })}
      </ul>
    </Card>
  );
}

export function DriverConfirmPanel({ busId }: { busId: string }) {
  const asks = useFleet((s) => s.asks);
  const now = useFleet((s) => s.now) || Date.now();
  const confirmAsk = useFleet((s) => s.confirmAsk);
  const pending = liveAsks(asks, now).filter((a) => a.busId === busId && a.status === "pending");
  const confirmed = liveAsks(asks, now).filter((a) => a.busId === busId && a.status === "confirmed");

  return (
    <Card>
      <p className="text-xs font-medium uppercase tracking-wide text-accent">Passenger pings</p>
      <h2 className="font-display text-2xl font-semibold tracking-tight">Confirm you are coming</h2>
      <p className="mt-1 text-sm text-muted">
        Waiting passengers asked if this bus will arrive at SITEX. One tap posts your plate on the public board.
      </p>
      {pending.length === 0 && confirmed.length === 0 && (
        <p className="mt-4 text-sm text-muted">No passenger asks right now.</p>
      )}
      <ul className="mt-4 flex flex-col gap-3">
        {pending.map((a) => (
          <li key={a.id} className="rounded-lg border border-warn/35 bg-warn/10 px-4 py-4">
            <p className="text-xs font-medium uppercase tracking-widest text-warn">Waiting for you</p>
            <p className="mt-1 font-display text-2xl font-semibold">
              Are you coming to SITEX?
            </p>
            <p className="text-sm text-muted">
              {a.destination} · plate {a.plate}
            </p>
            <Button className="mt-3 w-full" size="lg" onClick={() => confirmAsk(a.id)}>
              Confirmed
            </Button>
          </li>
        ))}
        {confirmed.map((a) => (
          <li key={a.id} className="rounded-lg border border-ok/30 bg-ok/10 px-4 py-3">
            <p className="text-xs font-bold uppercase tracking-wide text-ok">Posted on public board</p>
            <p className="font-mono text-lg font-bold">{a.plate}</p>
          </li>
        ))}
      </ul>
    </Card>
  );
}
