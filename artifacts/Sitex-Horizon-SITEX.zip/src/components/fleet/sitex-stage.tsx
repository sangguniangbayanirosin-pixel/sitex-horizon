import { GlitterField } from "@/components/fleet/glitter-field";
import { cn } from "@/lib/utils";

function DissolveBlobs() {
  return (
    <>
      <span className="dissolve-blob blob-a" />
      <span className="dissolve-blob blob-b" />
      <span className="dissolve-blob blob-c" />
      <span className="dissolve-blob blob-d" />
      <span className="dissolve-veil" />
    </>
  );
}

export function SitexStage() {
  return (
    <>
      <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden dissolve-stage" aria-hidden>
        <DissolveBlobs />
      </div>
      <GlitterField />
    </>
  );
}

export function SitexLiveReel({ className }: { className?: string }) {
  return (
    <div className={cn("dissolve-stage relative overflow-hidden", className)} aria-hidden>
      <DissolveBlobs />
    </div>
  );
}
