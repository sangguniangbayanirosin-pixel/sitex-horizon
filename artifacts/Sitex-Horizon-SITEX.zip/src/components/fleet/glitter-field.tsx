import { useEffect, useRef } from "react";

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  a: number;
  kind: 0 | 1;
  spin: number;
  tw: number;
};

function seed(w: number, h: number, n: number): Particle[] {
  const out: Particle[] = [];
  for (let i = 0; i < n; i++) {
    out.push({
      x: Math.random() * w,
      y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.15,
      vy: 0.18 + Math.random() * 0.45,
      r: i % 5 === 0 ? 3.4 + Math.random() * 2.2 : 0.7 + Math.random() * 1.6,
      a: 0.25 + Math.random() * 0.55,
      kind: i % 5 === 0 ? 1 : 0,
      spin: Math.random() * Math.PI * 2,
      tw: Math.random() * Math.PI * 2,
    });
  }
  return out;
}

function flake(ctx: CanvasRenderingContext2D, p: Particle) {
  ctx.save();
  ctx.translate(p.x, p.y);
  ctx.rotate(p.spin);
  ctx.globalAlpha = p.a;
  ctx.strokeStyle = "rgba(210, 235, 255, 0.95)";
  ctx.lineWidth = 0.9;
  const arm = p.r;
  for (let i = 0; i < 6; i++) {
    ctx.rotate(Math.PI / 3);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, arm);
    ctx.moveTo(0, arm * 0.45);
    ctx.lineTo(arm * 0.22, arm * 0.62);
    ctx.moveTo(0, arm * 0.45);
    ctx.lineTo(-arm * 0.22, arm * 0.62);
    ctx.stroke();
  }
  ctx.restore();
}

export function GlitterField() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let w = 0;
    let h = 0;
    let parts: Particle[] = [];
    let mx = -9999;
    let my = -9999;
    let px = -9999;
    let py = -9999;
    let raf = 0;
    let running = true;

    const resize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      parts = seed(w, h, reduce ? 40 : 110);
    };

    const onMove = (e: PointerEvent) => {
      mx = e.clientX;
      my = e.clientY;
    };

    const tick = () => {
      if (!running) return;
      ctx.clearRect(0, 0, w, h);
      const dxm = mx - px;
      const dym = my - py;
      px = mx;
      py = my;

      for (const p of parts) {
        const dx = p.x - mx;
        const dy = p.y - my;
        const dist = Math.hypot(dx, dy) || 1;
        const radius = 140;
        if (dist < radius) {
          const force = ((radius - dist) / radius) * 0.9;
          p.vx += (dx / dist) * force + dxm * 0.012;
          p.vy += (dy / dist) * force * 0.55 + dym * 0.012;
        }
        p.vx *= 0.94;
        p.vy = p.vy * 0.94 + 0.04;
        p.x += p.vx;
        p.y += p.vy;
        p.spin += 0.01 + p.r * 0.002;
        p.tw += 0.05;
        if (p.y > h + 8) {
          p.y = -8;
          p.x = Math.random() * w;
        }
        if (p.x < -8) p.x = w + 8;
        if (p.x > w + 8) p.x = -8;

        if (p.kind === 1) {
          flake(ctx, p);
        } else {
          const spark = 0.45 + Math.sin(p.tw) * 0.35;
          ctx.globalAlpha = p.a * spark;
          ctx.fillStyle = "rgba(186, 230, 253, 1)";
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fill();
          ctx.globalAlpha = p.a * spark * 0.45;
          ctx.fillStyle = "rgba(255, 255, 255, 1)";
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r * 0.45, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      ctx.globalAlpha = 1;
      raf = requestAnimationFrame(tick);
    };

    resize();
    window.addEventListener("resize", resize);
    window.addEventListener("pointermove", onMove, { passive: true });
    if (reduce) {
      tick();
      cancelAnimationFrame(raf);
    } else {
      raf = requestAnimationFrame(tick);
    }

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("pointermove", onMove);
    };
  }, []);

  return (
    <canvas
      ref={ref}
      className="pointer-events-none fixed inset-0 z-0"
      aria-hidden
    />
  );
}
